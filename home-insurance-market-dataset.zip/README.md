# Home Insurance Market – Structured Dataset

This repository contains a structured dataset created from publicly available qualitative insights from the Home Insurance Market report on NextMSC.

## Files Included
- **market_overview.csv** – Contains estimated market insights and notes.
- **segmentation.csv** – Contains segmentation by coverage type, end user, distribution channel, and application.
- **metadata.json** – Includes metadata such as source URL and dataset information.
- **README.md** – Documentation explaining dataset structure and usage.

## Source
Report: https://www.nextmsc.com/report/home-insurance-market-bf3587

## Usage
This dataset is suitable for:
- Market analysis  
- Academic & policy research  
- Insurance modeling  
- Dashboard development  

